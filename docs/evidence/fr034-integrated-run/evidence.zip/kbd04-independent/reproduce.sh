#!/bin/bash
# Run from APS-Dev workspace root. All package/build/browser work occurs in Docker.
set -euo pipefail
base="$PWD/temp/fr034-integrated-run/kbd04-independent"
[[ -f "$base/product/qa/fr034-boundary-source-sha256.json" ]]
[[ -d "$PWD/.praetor/sdk" ]]
# Preserve the recorded result; caller chooses a fresh output directory.
: "${KBD04_REPLAY_OUT:?Set a new empty absolute evidence directory}"
[[ -d "$KBD04_REPLAY_OUT" && -z $(ls -A "$KBD04_REPLAY_OUT") ]]
docker run --rm --init --mount "type=bind,src=$base/product,dst=/input,readonly" --mount "type=bind,src=$PWD/.praetor/sdk,dst=/workspace/.praetor/sdk,readonly" --mount "type=bind,src=$base/probe,dst=/probe,readonly" --mount "type=bind,src=$KBD04_REPLAY_OUT,dst=/evidence" node:22-slim bash /probe/run-container.sh
