import fs from 'node:fs';
import assert from 'node:assert/strict';
import {chromium} from 'playwright';
import {startValidation} from './fr034-integration-runner.mjs';
const out=process.env.OWN_OUT;fs.mkdirSync(out,{recursive:true});
const report={sha:process.env.FR034_PRODUCT_SHA,mode:process.env.OWN_MODE,cases:[],errors:[],network:[],steps:'Actual App; native Tab/Arrow/Enter/Space; mouse click only in mouse cases; DOM reads and banner removal are instrumentation.'};
const run=await startValidation();let browser;
async function reach(p,l){for(let i=0;i<800;i++){if(await l.evaluate(e=>e===document.activeElement))return i;await p.keyboard.press('Tab');}throw Error('unreachable');}
async function choose(p,l,id){await reach(p,l);const [a,b]=await l.evaluate((e,id)=>[e.selectedIndex,[...e.options].findIndex(o=>o.value===id)],id);assert.ok(b>=0);for(let i=0;i<Math.abs(b-a);i++)await p.keyboard.press(b>a?'ArrowDown':'ArrowUp');await p.keyboard.press('Enter');assert.equal(await l.inputValue(),id);}
async function snap(p,stem){const cdp=await p.context().newCDPSession(p);fs.writeFileSync(`${out}/${stem}.native-ax.json`,JSON.stringify(await cdp.send('Accessibility.getFullAXTree'),null,2));await cdp.detach();fs.writeFileSync(`${out}/${stem}.html`,await p.content());fs.writeFileSync(`${out}/${stem}.aria.txt`,await p.locator('body').ariaSnapshot());await p.screenshot({path:`${out}/${stem}.png`});}
async function focus(p){return p.evaluate(()=>{const e=document.activeElement,r=e.getBoundingClientRect(),s=getComputedStyle(e);let clip={left:Math.max(0,r.left),right:Math.min(innerWidth,r.right),top:Math.max(0,r.top),bottom:Math.min(innerHeight,r.bottom)};for(let a=e.parentElement;a;a=a.parentElement){const q=a.getBoundingClientRect(),c=getComputedStyle(a);if(/hidden|auto|scroll|clip/.test(c.overflowX)){clip.left=Math.max(clip.left,q.left);clip.right=Math.min(clip.right,q.right);}if(/hidden|auto|scroll|clip/.test(c.overflowY)){clip.top=Math.max(clip.top,q.top);clip.bottom=Math.min(clip.bottom,q.bottom);}}const hits=[.2,.5,.8].flatMap(x=>[.2,.5,.8].map(y=>{const h=document.elementFromPoint(clip.left+(clip.right-clip.left)*x,clip.top+(clip.bottom-clip.top)*y);return h===e||e.contains(h);}));return {tag:e.tagName,text:e.getAttribute('aria-label')||e.textContent?.slice(0,180),selected:e.getAttribute('data-selected'),focusVisible:e.matches(':focus-visible'),outline:s.outline,outlineOffset:s.outlineOffset,rect:r.toJSON(),clip,hits,body:e===document.body,viewport:{width:innerWidth,height:innerHeight},scrollY};});}
try{
 browser=await chromium.launch({headless:true,args:['--no-sandbox']});report.browser=browser.version();report.sourceHashes=run.manifest.sourceHashes;const inputBefore=await run.call('/state');
 for(const width of [640,1100]){
  const p=await browser.newPage({viewport:{width,height:900}});p.on('pageerror',e=>report.errors.push(e.message));p.on('response',r=>{if(r.url().includes('/api/'))report.network.push({path:new URL(r.url()).pathname,status:r.status()});});
  await p.goto(run.url);await p.getByText('当前权限：planner',{exact:false}).waitFor();await p.locator('body > aside').evaluate(e=>e.remove());
  const picker=p.locator('.plan-list select'),reason=p.getByLabel('操作原因',{exact:true}),problem=p.locator('.fr034 .finding').filter({hasText:'MACHINE_OVERLAP'}),search=p.getByLabel('搜索任务',{exact:true}),reveal=p.getByRole('button',{name:'显示选中任务',exact:true});
  await reach(p,reason);await p.keyboard.insertText('APS-Test KBD04 independent acceptance');await choose(p,picker,run.manifest.corruptPlanId);await reach(p,p.locator('.fr034').getByRole('button',{name:'主动运行独立检查',exact:true}));await p.keyboard.press('Enter');await problem.waitFor();await p.waitForFunction(()=>document.querySelector('.fr034 > button')?.getAttribute('aria-disabled')==='false');
  const savedBefore=await run.call('/plans');
  for(const method of ['Enter','Space','mouse'])for(const transition of ['search','state']){
   const c={width,method,transition};report.cases.push(c);
   await reach(p,problem);await p.keyboard.press('Enter');await p.waitForTimeout(80);assert.equal(await p.locator('.fr033-task[data-selected="true"]').count(),2);
   if(transition==='search'){await reach(p,search);await p.keyboard.insertText('APS-TEST-NO-MATCH');assert.equal(await search.inputValue(),'APS-TEST-NO-MATCH');}
   else {const state=p.getByLabel('计划状态',{exact:true});await choose(p,state,'unplanned');}
   assert.equal(await p.locator('.fr033-task').count(),0);assert.match(await p.locator('.fr033').innerText(),/选中任务被筛选隐藏/);assert.match(await p.getByLabel('选中任务详情',{exact:true}).innerText(),/A-MIX/);c.hidden=await focus(p);
   await reach(p,reveal);c.before=await focus(p);assert.equal(c.before.tag,'BUTTON');
   if(method==='mouse')await reveal.click();else await p.keyboard.press(method);
   await p.waitForTimeout(100);c.after=await focus(p);assert.equal(await reveal.count(),0);assert.equal(await search.inputValue(),'');assert.equal(await p.getByLabel('计划状态',{exact:true}).inputValue(),'');
   c.ids=await p.locator('.fr033-task[data-selected="true"]').evaluateAll(es=>es.map(e=>e.textContent.split(' · ')[0]).sort());assert.deepEqual(c.ids,['A-FILL','A-MIX']);assert.match(await p.getByLabel('问题区间详情').innerText(),/\[20,30\)/);
   c.focusPass=!c.after.body&&c.after.tag==='BUTTON'&&c.after.selected==='true'&&c.after.hits.every(Boolean)&&c.after.rect.bottom<=901&&c.after.rect.top>=0&&(method==='mouse'||c.after.focusVisible);
   await snap(p,`${width}-${method}-${transition}`);
   if(process.env.OWN_MODE==='fixed')assert.ok(c.focusPass,JSON.stringify(c.after));else assert.equal(c.after.body,true,'parent must independently reproduce BODY');
   await p.keyboard.press('Tab');const tabBefore=await focus(p);await p.waitForTimeout(250);c.afterTab=await focus(p);assert.deepEqual(c.afterTab,tabBefore);assert.ok(!c.afterTab.body);c.noLateSteal=true;
   assert.deepEqual(await run.call('/plans'),savedBefore);c.allSavedJSONUnchanged=true;
  }
  await choose(p,picker,run.manifest.jointPlanId);const preEmpty=await p.locator('.fr033-task').evaluateAll(es=>es.map(e=>e.getAttribute('aria-label'))),emptyWindow={from:await p.getByLabel('窗口开始分钟',{exact:true}).inputValue(),to:await p.getByLabel('窗口结束分钟',{exact:true}).inputValue()};assert.ok(preEmpty.length>0);const only=p.getByLabel('仅显示问题任务',{exact:true});await reach(p,only);await p.keyboard.press('Space');await p.waitForTimeout(80);assert.equal(await p.locator('.fr033-task').count(),0);assert.equal(await only.evaluate(e=>e===document.activeElement),true);assert.equal(await reveal.count(),1);assert.match(await p.locator('.fr033').innerText(),/选中任务被筛选隐藏/);await p.keyboard.press('Space');await p.waitForTimeout(80);assert.deepEqual(await p.locator('.fr033-task').evaluateAll(es=>es.map(e=>e.getAttribute('aria-label'))),preEmpty);assert.equal(await only.evaluate(e=>e===document.activeElement),true);report.cases.push({width,emptyTransitions:true,preEmpty,emptyWindow,pass:true});
  assert.deepEqual(await run.call('/plans'),savedBefore);await p.close();
 }
 const after=await run.call('/state');assert.deepEqual(after.data,inputBefore.data);assert.equal(after.revision,inputBefore.revision);report.currentInputUnchanged=true;report.completed=true;assert.deepEqual(report.errors,[]);
}finally{fs.writeFileSync(out+'/report.json',JSON.stringify(report,null,2));await browser?.close();await run.close();}
