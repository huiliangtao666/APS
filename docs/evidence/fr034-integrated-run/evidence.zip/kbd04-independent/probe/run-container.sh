#!/bin/bash
set -euo pipefail
mkdir -p /workspace/apps/aps-fr032
cp -a /input/. /workspace/apps/aps-fr032/
cd /workspace/apps/aps-fr032
npm ci --no-audit --no-fund > /evidence/install.log 2>&1
npm install --no-save --package-lock=false --ignore-scripts playwright@1.56.1 >> /evidence/install.log 2>&1
npx playwright install --with-deps chromium > /evidence/browser-install.log 2>&1
cp /probe/browser.mjs qa/own-kbd04.mjs
export FR033_DISPOSABLE_VALIDATION=1 FR034_PRODUCT_SHA=4e11da6c768e6eeb026f38e1d247191cbe3c2cf8 FR034_PRODUCT_LABEL='FR034 KBD04 boundary repair round1; parent 02a5e307f4b731ebb2b1882ed02e16a7e20c52e3' FR034_SOURCE_MANIFEST=qa/fr034-boundary-source-sha256.json
OWN_MODE=fixed OWN_OUT=/evidence/own-fixed node --experimental-strip-types qa/own-kbd04.mjs
