# APS FR-006 配置基础（DEC-02 前置）

这是从 `apps/aps-r1/` 建立的独立代码副本，供 FR-006 配置 CRUD、CSV 字段与 APS-Test 用例约定评审。它没有被绑定到 Portal，也没有发布。R2.1 预览项目未改动。

## 已实现

- 新增“工装配置（仅配置）”表：编码、名称、适用工序、可用数量、每任务需求数量、提前占用分钟、后延占用分钟、启用状态和说明。
- 复用表格新增/编辑/删除、CSV 导入/导出、字段查询和浏览器本地持久化。持久化键为 `aps-fr006-foundation-data-v1`，与 R1 隔离。
- 工装 CSV 导入检查必需表头、唯一工装编码、必填值、正整数数量、非负整数提前/后延分钟及启用值。失败整批拒绝并保留已有表。
- 页面持续呈现工装资源状态“未启用 / 未检查”。没有将工装表传入排程逻辑。

## 目录

- `src/App.tsx`：工装数据表、界面 CRUD、导入校验。
- `sample-data/FR-006/18_工装配置.csv`：导入样例。
- `docs/FR-006-CONTRACT.md`：字段、校验和接口边界契约。
- `docs/APS-TEST-FR006.md`：APS-Test 配置/导入验收用例约定。
- `docs/FR-006-MERGE-BACK.md`：DEC-02 后回迁/合并步骤及当前待决项。

当前数据接口只有浏览器 localStorage；本副本没有工装服务端 API、跨用户持久化或排程占用引擎。文档中的 REST 路由是待决后可采用的建议契约，不是已实现接口。

## 自动回归与容器构建

在 APS 仓库根目录执行：

```sh
npm test --prefix prototypes/fr006-config-only
docker build -f prototypes/fr006-config-only/Dockerfile -t aps-fr006-config-only .
```

Docker 构建需要受信任的 Praetor SDK 包 `/.praetor/sdk/lite-app-{runtime,server}.tgz`（相对于仓库根目录）；这些 workspace SDK 包不纳入 Git。构建阶段执行 TypeScript 检查和 Vite/server bundle，运行阶段监听 3000 端口。不要把 SDK tarball 复制进提交。

自动回归覆盖工装记录字段契约及必填、重复编码、数量、占用偏移和启用值校验；浏览器 CRUD、下载/上传交互仍由 APS-Test 按 `docs/APS-TEST-FR006.md` 执行。
