import json,pathlib,re,hashlib,sys,datetime
root=pathlib.Path(sys.argv[1]); pin='4e11da6c768e6eeb026f38e1d247191cbe3c2cf8'
def read(p): return json.loads((root/p).read_text())
k=read('regression/keyboard-report.json'); u=read('regression/unknown-browser-report.json'); h=read('regression/confirmed-api-report.json'); b=read('boundary/boundary-report.json')
assert k['productSHA']==b['productSHA']==pin
assert k['completed'] and b['completed'] and b['allPassed']
assert not k['errors'] and not b['errors'] and not u['errors']
assert len(k['keyboard'])==6 and all(x['pass'] for x in k['keyboard'])
assert len([x for x in k['results'] if x.get('pass') is True])==22
assert not any(x.get('pass') is False for x in k['results'])
assert len(u['results'])==24 and all(x['passed'] for x in u['results'])
assert len([x for x in b['results'] if x.get('pass') is True])==14
assert not any(x.get('pass') is False for x in b['results'])
assert len(h['checks'])==4 and len(h['requests'])==19
expected=[201,200,200,200,200,200,200,200,409,409,403,200,200,200,200,200,200,200,200]
assert [x['status'] for x in h['requests']]==expected
for report,hashfield in [(k,'sourceHashes'),(b,'sourceHashes'),(u,'hashes')]:
 assert len(report[hashfield])==110
manifest=json.loads(pathlib.Path('apps/aps-fr032/qa/fr034-boundary-source-sha256.json').read_text())['files']
assert k['sourceHashes']==b['sourceHashes']==u['hashes']==manifest
logs={};total=0
for f in sorted((root/'regression/tests').glob('*.log')):
 text=f.read_text(); counts=[int(x) for x in re.findall(r'^# tests (\d+)$',text,re.M)]; passed=[int(x) for x in re.findall(r'^# pass (\d+)$',text,re.M)]
 assert not any(int(x) for x in re.findall(r'^# (?:fail|cancelled|skipped|todo) (\d+)$',text,re.M)),f
 if counts: assert counts==passed,f; total+=sum(counts);logs[f.name]=sum(counts)
assert total==441,total
parsed=[]
for f in sorted(root.rglob('*.json')): json.loads(f.read_text());parsed.append(str(f.relative_to(root)))
out={'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'product_sha':pin,'tap_total_one_run':total,'tap_by_log':logs,'keyboard_assertions':6,'keyboard_functional_groups':22,'keyboard_measurements':len(k['results'])-22,'keyboard_audit_observations':len(k['audit']),'unknown_groups':24,'history_groups':4,'history_response_statuses':[x['status'] for x in h['requests']],'boundary_assertion_groups':14,'boundary_measurements':len(b['results'])-14,'boundary_audit_observations':len(b['audit']),'source_hashes_per_browser':110,'browser_versions':{'keyboard':k['browser'],'unknown':u['browser'],'boundary':b['browser']},'json_files_parsed':len(parsed),'json_paths':parsed,'all_required_gates':True,'counting':'only final complete run; earlier failed run, parallel replay, historical runs and overlapping browser scenarios are not added to 441'}
(root/'delivery-validation.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
