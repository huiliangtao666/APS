#!/bin/sh
set -eu
cd /workspace/apps/app
B12_EVIDENCE=/evidence/b12 R4_EVIDENCE=/evidence/b12 node --experimental-strip-types --test src/lib/process-config.test.mjs src/lib/process-source.test.mjs src/lib/process-cooling.test.mjs qa/b12-test-core.mjs qa/b12-dev-profile.test.mjs qa/b12-dev-seams.test.mjs > /evidence/b12/with-complete-fixture-tests.log 2>&1
