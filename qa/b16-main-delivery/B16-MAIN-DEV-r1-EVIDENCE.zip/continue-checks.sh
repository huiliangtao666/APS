#!/bin/sh
set -u
cd /workspace/apps/app
B12_EVIDENCE=/evidence/b12 R4_EVIDENCE=/evidence/b12 node --experimental-strip-types --test src/lib/process-config.test.mjs src/lib/process-source.test.mjs src/lib/process-cooling.test.mjs qa/b12-test-core.mjs qa/b12-dev-profile.test.mjs qa/b12-dev-seams.test.mjs > /evidence/b12/tests.log 2>&1
printf "B12 exit %s\n" "$?"
B15_EVIDENCE=/evidence/b15 node --experimental-strip-types --test qa/b15-test-core.test.mjs qa/b15-test-seams.test.mjs qa/b15-dev-profiles.test.mjs qa/b15-dev-seams.test.mjs src/lib/plan-comparison.test.mjs > /evidence/b15/tests.log 2>&1
printf "B15 exit %s\n" "$?"
R7_EVIDENCE=/evidence/r7 node --experimental-strip-types --test qa/r7-test-core.mjs qa/r7-dev-application.test.mjs src/lib/data-query.test.mjs qa/scoped-report.test.mjs qa/confirmation.test.mjs qa/delivery.test.mjs qa/result-assessment.test.mjs > /evidence/r7/tests.log 2>&1
printf "R7 exit %s\n" "$?"

