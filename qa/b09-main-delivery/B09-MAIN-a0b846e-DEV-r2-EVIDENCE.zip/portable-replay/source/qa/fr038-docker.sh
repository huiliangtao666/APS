#!/usr/bin/env bash
# Run from a host with Docker. All install/build/server/browser work stays in one disposable container.
set -euo pipefail
: "${FR038_REPO:?Absolute checkout directory required}"
: "${FR038_SDK:?Absolute directory containing the two existing SDK tgz required}"
: "${FR038_OUT:?New empty absolute output directory required}"
[[ -d "$FR038_OUT" && -z $(ls -A "$FR038_OUT") ]] || { echo 'Output must exist and be empty' >&2; exit 2; }
docker run --rm --init --user root \
 --mount "type=bind,src=$FR038_REPO,dst=/input,readonly" \
 --mount "type=bind,src=$FR038_SDK,dst=/workspace/.praetor/sdk,readonly" \
 --mount "type=bind,src=$FR038_OUT,dst=/evidence" \
 -e FR034_KBD_MODE -e FR034_PRODUCT_SHA -e FR034_SOURCE_MANIFEST -e FR034_PRODUCT_LABEL node:22-slim bash -lc '
 mkdir -p /workspace/apps/aps-fr032 && cp -a /input/. /workspace/apps/aps-fr032/ &&
 cd /workspace/apps/aps-fr032 && rm -rf node_modules dist &&
 npm ci --no-audit --no-fund &&
 npm install --no-save --package-lock=false --ignore-scripts playwright@1.56.1 react-test-renderer@18.3.1 &&
 npx playwright install --with-deps chromium &&
 bash qa/fr038-checks.sh'
