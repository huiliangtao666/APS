import test from 'node:test';import assert from 'node:assert/strict';
import {scopedReport,reportCsv} from '../server/scoped-report.mjs';import {freezeRunInput,inputHash} from '../server/run-input.mjs';import {calculate,seed} from '../server/planner.ts';import {materialFixture} from './material-fixture.mjs';import {resourceLoad} from '../src/lib/resource-load.mjs';import {comparePlans} from '../src/lib/plan-comparison.mjs';
function fixture(){const d=materialFixture(seed),f=freezeRunInput(d,{},'2026-10-29T00:00:00Z'),v=inputHash(d),p={...calculate(f.executionData,0,'2026-10-29T00:00:00Z',f.conditions),conditions:f.conditions,id:'P',runId:'R',inputVersionId:v,snapshotHash:f.snapshotHash};return {data:d,plans:[p],runs:[{id:'R',inputVersionId:v,snapshotHash:f.snapshotHash,conditions:f.conditions,executionData:f.executionData}],inputVersions:{[v]:{data:d}},records:[],revision:0};}
const q=kind=>({kind,planId:'P',start:0,end:120,text:'',order:''});
test('FR035 six views reuse exact saved input, FR032 load and trial comparison',()=>{const s=fixture(),p=s.plans[0],d=s.data;const load=resourceLoad({...p,inputSnapshot:d},{start:0,end:120});
 for(const kind of ['orders','tasks','occupation','materials','unplanned','differences']){const query={...q(kind),...(kind==='differences'?{otherPlanId:'P'}:{})},r=scopedReport(s,query);assert.equal(r.viewId.length,64);assert.equal(r.provenance.inputVersionId,p.inputVersionId);assert.ok(reportCsv(r).includes(r.viewId));if(kind==='materials')assert.deepEqual(r.rows.map(row=>JSON.parse(row[1]).record),load.materials);if(kind==='differences')assert.equal(r.comparison.impact.claim,comparePlans(p,d,p,d).impact.claim);}
});
test('FR035 full-record decimal quantities and half-open task scope remain identical; no order summing',()=>{const s=fixture();let r=scopedReport(s,q('tasks'));assert.ok(r.rows.length);const start=Number(JSON.parse(r.rows[0][1]).record['开始分钟']);r=scopedReport(s,{...q('tasks'),start:start-1,end:start});assert.ok(r.rows.every(row=>Number(JSON.parse(row[1]).record['开始分钟'])<start));const all=scopedReport(s,q('orders'));assert.equal(all.rows.length,s.data.orders.length);assert.deepEqual(scopedReport(s,{...q('orders'),start:999,end:1000}).rows,all.rows);assert.equal(scopedReport(s,{...q('orders'),text:'no-such-record'}).rows.length,0);assert.equal(scopedReport(s,{...q('orders'),order:'no-such-order'}).rows.length,0);});
test('FR035 rejects malformed query, scope injection and missing/corrupt history',()=>{for(const patch of [{start:null},{end:0},{kind:'__proto__'},{planId:1},{role:'supervisor'},{otherPlanId:'P'},{text:[]},{order:{}}])assert.throws(()=>scopedReport(fixture(),{...q('tasks'),...patch}));const s=fixture();s.inputVersions={};assert.throws(()=>scopedReport(s,q('tasks')),/historical_inputs_unavailable/);const c=fixture();c.runs[0].executionData={};assert.throws(()=>scopedReport(c,q('tasks')),/historical_inputs_unavailable/);});
test('FR035 frozen history survives current input changes; CSV guards formulas, quotes and newlines',()=>{const s=fixture(),r=scopedReport(s,q('orders'));s.data=structuredClone(s.data);s.data.orders[0]['合格需求']='999';s.revision++;assert.deepEqual(scopedReport(s,q('orders')),r);const csv=reportCsv({...r,rows:[['=HYPERLINK("x")',' a,\r\n"b"'],[' \t+CMD','0.1000000000000000001']]});assert.ok(csv.includes('"\'=HYPERLINK(""x"")"'));assert.ok(csv.includes('" a,\r\n""b"""'));assert.ok(csv.includes('0.1000000000000000001'));assert.ok(csv.includes("' \t+CMD"));});

test('FR035 semantically identical query key order retains identity and cannot widen saved run orders',()=>{const s=fixture(),a=q('orders'),b=Object.fromEntries(Object.entries(a).reverse());assert.deepEqual(scopedReport(s,a),scopedReport(s,b));const p=s.plans[0],run=s.runs[0];p.conditions=structuredClone(p.conditions);p.conditions.orderIds=[p.conditions.orderIds[0]];run.conditions=p.conditions;run.snapshotHash=inputHash({conditions:run.conditions,executionData:run.executionData});p.snapshotHash=run.snapshotHash;const report=scopedReport(s,a);assert.equal(report.rows.length,1);assert.equal(JSON.parse(report.rows[0][1]).orderId,p.conditions.orderIds[0]);});

test('FR035 order filter handles both grouped diff arrays and per-order delivery objects',()=>{const s=fixture();assert.deepEqual(scopedReport(s,{...q('differences'),otherPlanId:'P',order:'absent-order'}).rows,[]);const order=s.plans[0].conditions.orderIds[0];const r=scopedReport(s,{...q('differences'),otherPlanId:'P',order});assert.ok(r.rows.every(row=>JSON.parse(row[1]).orderId===order||JSON.parse(row[1]).record.orderId===order));});


test('FR035 DIFF-ORDER01 before/after-only task references, shared rows and reused IDs resolve against saved sides',()=>{
 const s=fixture(),left=s.plans[0],right=structuredClone(left);right.id='P2';s.plans.push(right);
 // Deliberate structural controls supplement the genuine saved-route browser case.
 left.tasks=[{id:'before-only',orderId:'A'},{id:'shared',orderId:'A'},{id:'other',orderId:'B'},{id:'reused',orderId:'B'}];
 right.tasks=[{id:'after-only',orderId:'A'},{id:'shared',orderId:'A'},{id:'other',orderId:'B'},{id:'reused',orderId:'A'}];
 const row=(resourceId,links)=>({type:'空间',resourceId,quantity:100,unit:'kg',start:0,end:20,...links});
 left.resourceReservations=[row('before',{taskId:'before-only'}),row('shared',{taskIds:['shared','other']}),row('unrelated',{taskId:'other'}),row('reused-before',{taskId:'reused'})];
 right.resourceReservations=[row('after',{taskIds:['after-only']}),{...row('shared',{taskIds:['shared','other']}),quantity:200},row('unrelated',{taskId:'other'})];
 const snapshot=structuredClone(s),read=(a,b,order='')=>scopedReport(s,{...q('differences'),planId:a,otherPlanId:b,order});
 const resources=r=>r.rows.map(x=>JSON.parse(x[1])).filter(x=>x.category==='resources');
 for(const [a,b] of [['P','P2'],['P2','P']]){
  const all=resources(read(a,b)),filtered=resources(read(a,b,'A'));
  assert.equal(all.length,4);assert.equal(filtered.length,3);
  const selected=all.filter(x=>['before','after','shared'].some(id=>[...(x.record.before||[]),...(x.record.after||[])].some(v=>v.resourceId===id)));
  assert.deepEqual(filtered,selected);assert.deepEqual(resources(read(a,b,'absent')),[]);
  const shared=filtered.find(x=>[...(x.record.before||[]),...(x.record.after||[])].some(v=>v.resourceId==='shared'));
  assert.deepEqual([shared.record.before[0].quantity,shared.record.after[0].quantity],a==='P'?[100,200]:[200,100]);
  assert.equal(resources(read(a,b,'B')).length,2);
 }
 assert.deepEqual(s,snapshot);
});
