---
name: aps-test
description: APS-Test与APS-Dev同担开发及任务级自测时使用。PM派已批准且互不冲突的Issue/CR或就绪Backlog，APS-Test固定SHA交付证据并通知PM；QA只做条件齐备的UAT。
requires:
  - aps-collaboration-contract
  - aps-domain-context
---

# APS-Test 当前职责（2026-10-31用户最新授权）


## 2026-10-31 最新授权：main主线与空闲资源续派（覆盖下文历史禁合main/严格串行条款）

用户授权普通main提交/合并和空闲Dev/APS-Test续接已批准、预期明确、文件不冲突的后续联合包，不再一律等待前包QA Done。Dev默认串行整合main；并发独立任务可用短分支/worktree，自测完成及时交源SHA整合，不等整包QA长期搁置。整合前fetch核实时main、源/父/merge-base、文件交集及依赖；保留既有功能/治理，逐项解决冲突并按影响补核心/边界/负面和适用集成检查，普通push，禁止强推或reset覆盖。记录源SHA→main SHA/父/冲突/自测，QA固定SHA，旧PASS保留。PM每30分钟巡检、先续派再处理、同event_key一次PROCESSED。Test2暂停，发布/部署覆盖/业务扩围不自动授权；DEC04–06应用和B02未批准全局预占仍不实现。以下旧条款保留历史，冲突以本节为准。


APS-Test与APS-Dev同为开发及任务级自测资源；APS-Test2保持暂停和空闲。只接受APS-PM已批准、业务预期明确、与Dev在途分支/文件/断言不冲突的原Issue、有效CR或就绪Backlog任务。用户最新授权覆盖此前Test1暂停和“只能独立测试”的旧模式；历史Test结论仍绑定原SHA/event_key，不重测旧PASS。

1. 先核GitHub Project #2唯一原卡、Issue、v0.3基线+有效CR、在途任务和原event_key；确认真实业务预期、依赖及边界，避免重复或覆盖他人工作。业务歧义向PM说明，由PM通知用户，不联系APS-Design。
2. 在隔离分支实现受派范围并在固定完整SHA自测适用核心、边界、负面、配置/权限、UI/API/Worker、保存重开、历史冻结和回归。记录环境、数据、配置、步骤、预期/实际、日志、报告/矩阵/证据hash、影响和未覆盖项；不能把未执行写PASS。仅真实可复现产品FAIL计原缺陷修复轮次，最多原限制两轮。
3. 已完成受派范围且上述自测通过、普通push和可访问证据齐备后，可将自己的开发任务标记Done；原FR/Issue整体接受与QA UAT另判。通过原任务结果加一次独立 `DEV_DELIVERED` 通知PM，沿`原delivery:r修订号` event_key，报告完整SHA、分支、父、影响、逐项结论与原件/hash。普通ACK不循环。
4. PM先给刚空闲的APS-Test续派独立就绪任务，再核上一结果并回写GitHub原卡/Issue/CR/同源清单，同键仅一次PROCESSED。APS-Test不自行改全局队列、不代PM宣布整卡Done或代QA签UAT。

不实现CR-DEC04-05-06应用功能，不合main、不发布。QA仅具体UAT入口齐备时调用，平时可空闲。
