import {scheduleCoolingPairs} from './baseline-cooling.mjs';
import {prepareCoolingMembers} from '/workspace/apps/b12-process-core/src/lib/process-cooling-adapter.mjs';
import {b4Fixture} from '/workspace/apps/b12-process-core/qa/b4-fixture.mjs';
const f=b4Fixture('13','/workspace/temp/b4/inputs'),members=prepareCoolingMembers(f).members;
const old=scheduleCoolingPairs({members,endMinute:600});
const cooling=old.tasks.find(t=>t.loadBasis==='合格产出');
for(const m of members){m.minimumInputKg='300';m.readyMinute=0;}members[0].heatWindows=[[0,120],[180,600]];members[1].heatWindows=[[90,600]];
const common=scheduleCoolingPairs({members,endMinute:600});
console.log(JSON.stringify({baseline:'12d453d7cb03829dc609115e48c5e4c19af4a6ec',coolingLoad:{basis:cooling.loadBasis,actualExact:cooling.exactLoadKg,approvedExpected:{numerator:'240',denominator:'1'}},commonWindow:{actualTasks:common.tasks.length,actualFindings:common.findings,expected:'one compatible500kg heat group at180 with full120min and480 output; no under-min standalone250kg'}},null,2));
