from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timedelta,timezone
import json,csv,io,hashlib
p=Path('temp/b15-lossless');checks=[]
def check(name,expected,actual):
 assert expected==actual,(name,expected,actual)
 checks.append({'assertion':name,'expected':str(expected),'actual':str(actual),'result':'PASS'})
origin=datetime.fromisoformat('2026-11-02T08:00:00+08:00')
for id,count in [('12',5),('13',10),('14',10),('15',4),('17',5),('18',2)]:
 x=json.loads((p/'selftest'/f'worker-{id}.json').read_text());r=x['result'];d=r['input']['executionData'];plan=r['plan'];profile=x['profile']['data']
 check(id+' tasks',count,len(plan['tasks']))
 for table in ['originalInventory']+(['originalSupply','originalProgress','originalEvents'] if id=='15' else []):
  src=plan['inputCsvSources'][table];rows=list(csv.DictReader(io.StringIO(src['originalText'].lstrip('\ufeff'))))
  check(id+' '+table+' byte SHA256',src['sha256'],hashlib.sha256(src['originalText'].encode()).hexdigest())
  check(id+' '+table+' raw row values',rows,profile[table])
  check(id+' '+table+' physical rows',list(range(2,2+len(rows))),src['lines'])
  for i,s in enumerate(rows):
   key='任务编号' if table=='originalProgress' else '事件编号' if table=='originalEvents' else '批次编号'
   ms=[m for m in d['stageMappings'] if m['来源类别']==table and m['来源编号']==s[key]];check(id+' map unique '+s[key],1,len(ms));m=ms[0];params=json.loads(m['参数JSON']);check(id+' literal '+s[key],s,json.loads(m['源记录JSON']))
   if table in ['originalInventory','originalSupply']:
    supply=table=='originalSupply';runtime=next(v for v in d['supplies' if supply else 'inventory'] if v['供给编号' if supply else '批次编号']==m['运行编号'])
    check(id+' amount '+s[key],F(s['到料kg或个' if supply else '库存kg或个']),F(runtime['预计数量' if supply else '账面数量']))
    check(id+' reserved '+s[key],F(s['已占用kg或个']),F(runtime['已占用数量']))
    check(id+' unit '+s[key],next(z['单位'] for z in d['materials'] if z['物料编号']==s['物料编号']),params['unit'])
    for a,b in [('到达分钟','到达分钟'),('最早可用分钟','可用分钟'),('到期分钟','到期分钟')]:check(id+' minute '+s[key]+a,s[a],runtime[b])
    check(id+' date remains empty '+s[key],'',runtime['有效期'])
    check(id+' exact next day cutoff '+s[key],datetime.fromisoformat('2026-11-03T08:00:00+08:00'),origin+timedelta(minutes=int(s['到期分钟'])))
    check(id+' boundary explicit '+s[key],'截止前',runtime['到期边界'])
 for v in x['verification']['verification']['checks'].values():
  if v['status']=='problem':raise AssertionError((id,v))
 if id=='15':
  facts={f['工序编号']:f for f in d['executionFacts']};check('15 separately supplied output',F(240),F(facts['MIX']['工序完成数量']))
  consumed=sum((F(c['累计已用数量']) for c in d['executionMaterials']),F(0));check('15 raw250 conserved',F(250),consumed)
  for op,amount in [('MIX',250),('FILL',0)]:
   source=next(s for s in d['executionSources'] if s['事实编号']==facts[op]['事实编号']);parts=json.loads(source['原始分配JSON']);check('15 source '+op,F(amount),F(source['原始汇总耗料']));check('15 parts '+op,F(amount),sum((F(c['数量']) for c in parts),F(0)))
  requirement=F(240)/F('0.96')*F(650)/F(1000);check('15 independent future LEAN demand',F('162.5'),requirement)
  b=next(t for t in plan['tasks'] if t['id']=='B-MIX');check('15 B ready180',180,b['start'])
  demand=next(v for v in plan['materialDemands'] if v['orderId']=='B' and v['materialId']=='LEAN');check('15 B allocated',requirement,sum((F(a['exactQuantity']['numerator'])/F(a['exactQuantity']['denominator']) for a in demand['allocations']),F(0)))
  check('15 future receipt identity','RCPT-LEAN',demand['allocations'][0]['lotId']);check('15 supply is conditional',True,demand['allocations'][0]['conditional'])
  check('15 already-consumed lean exhausted',F(0),F(d['inventory'][0]['账面数量'])-sum((F(c['累计已用数量']) for c in d['executionMaterials'] if c['批次编号']==d['inventory'][0]['批次编号']),F(0)))
  g=next(g for g in d['personnelGroups'] if g['人员组编号']=='LP01');pool=[z for z in d['personnelPools'] if z['poolId']==g['poolId']];check('15 unique physical pool',1,len(pool));check('15 group2',2,int(g['人员数量']));check('15 unique capacity2',2,int(pool[0]['总人数']))
  doc=json.loads(d['originalResourceEvents'][0]['原账JSON']);old=[o for o in doc['occupancies'] if o.get('people')];check('15 unchanged historical people1',{'1'},set(o['quantity'] for o in old));check('15 historical released60',{60},set(o['end'] for o in old));check('15 historical ledger unchanged',profile['originalResourceEvents'],d['originalResourceEvents'])
# Independently derive expiry table, without importing application code.
for row in json.loads((p/'selftest/expiry-boundaries.json').read_text()):
 at=datetime.fromisoformat(row['at']);expiry=origin+timedelta(minutes=1440)
 check('boundary '+row['at']+row['boundary'],at<=expiry if row['boundary']=='含截止' else at<expiry,row['actual'])
(p/'independent-oracle.json').write_text(json.dumps({'checks':len(checks),'pass':len(checks),'fail':0,'method':'Python CSV/hashlib/datetime/Fraction; no JS mapper/scheduler/allocator','results':checks},ensure_ascii=False,indent=2))
print('independent',len(checks),'PASS')
