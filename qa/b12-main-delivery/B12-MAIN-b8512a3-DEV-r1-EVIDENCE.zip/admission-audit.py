from pathlib import Path
import json,csv,io,urllib.request,urllib.error,hashlib
out=Path('temp/main-b12/main-evidence/admission');out.mkdir(exist_ok=True)
def call(path,body=None):
 req=urllib.request.Request('http://127.0.0.1:18175/api'+path,data=json.dumps({'reason':'B12 progressive explicit-profile admission selftest',**body}).encode() if body else None,headers={'content-type':'application/json'})
 try:
  with urllib.request.urlopen(req) as r:return json.load(r)
 except urllib.error.HTTPError as e:
  x=json.load(e);return {**x,"valid":False,"httpStatus":e.code}
state=call('/state');before=Path('temp/main-b12/main-selftest-state/business.json').read_bytes()
for scene in ['12','13','14']:
 folder=Path('temp/main-b12/main-fixtures/originals/UAT-'+scene);files=[{'name':p.name,'text':p.read_bytes().decode('utf-8')} for p in sorted(folder.glob('*.csv')) if p.name[:2] in [str(i).zfill(2) for i in range(1,20)]]
 derived=json.loads(Path('temp/main-b12/main-fixtures/UAT-'+scene+'/IMPORT-REQUEST.json').read_text())['files'];layers=[]
 for name,overrides in [('raw19',[]),('explicit-order-options',['17_生产订单与交期.csv']),('explicit-fixed-pack-and-rule-contracts',['17_生产订单与交期.csv','11_工序工时配置.csv','16_排程规则配置.csv'])]:
  current=[next((d for d in derived if d['name']==f['name']),f) if f['name'] in overrides else f for f in files]
  preview=call('/imports/preview',{'revision':state['revision'],'inputStage':'supported','files':current});layers.append({'layer':name,'overriddenFiles':overrides,'valid':preview['valid'],'issues':preview['issues']})
 assert Path('temp/main-b12/main-selftest-state/business.json').read_bytes()==before
 (out/('UAT'+scene+'-progressive.json')).write_text(json.dumps({'originalFiles':19,'zeroWrite':True,'layers':layers},indent=2,ensure_ascii=False))
 print(scene,[(l['layer'],l['valid'],len(l['issues'])) for l in layers]);print([(i.get('table'),i.get('field'),i.get('message')or i.get('reason')) for i in layers[-1]['issues'][:8]])
