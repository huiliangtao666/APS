#!/bin/sh
set -u
cd /workspace/apps/app
mkdir -p /evidence/core /evidence/residual /evidence/b12 /evidence/b15 /evidence/r7
node --input-type=module -e 'import fs from "node:fs";import{createHash}from"node:crypto";const m=JSON.parse(fs.readFileSync("/source-manifest.json"));for(const[p,h]of Object.entries(m.files))if(createHash("sha256").update(fs.readFileSync(p)).digest("hex")!==h)throw Error(p);fs.writeFileSync("/evidence/source-check.json",JSON.stringify({sha:m.productSha,parents:m.parents,sourceFiles:Object.keys(m.files).length,allMatch:true,node:process.version},null,2))' || exit 1
node --test --test-concurrency=1 src/lib/*.test.mjs > /evidence/core/libraries.log 2>&1
printf 'libraries=%s\n' "$?"
node --experimental-strip-types --test --test-concurrency=1 server/auth/auth.test.mjs server/business.test.mjs server/shared-access.test.mjs > /evidence/core/business.log 2>&1
printf 'business=%s\n' "$?"
FR022_OUT=/evidence/fr022 RESIDUAL_OUT=/evidence/residual node --experimental-strip-types --test --test-concurrency=1 qa/b15-residual*.test.mjs qa/fr027.test.mjs qa/confirmation.test.mjs qa/joint-resources.test.mjs qa/fr022-maxlag-contract.test.mjs qa/b12-changeover-selftest.mjs > /evidence/residual/tests.log 2>&1
printf 'residual=%s\n' "$?"
B12_EVIDENCE=/evidence/b12 B12_DEV_OUT=/evidence/b12 B4_INPUTS=/fixtures/originals R4_EVIDENCE=/evidence/b12 node --experimental-strip-types --test --test-concurrency=1 src/lib/process-config.test.mjs src/lib/process-source.test.mjs src/lib/process-cooling.test.mjs qa/b12-test-core.mjs qa/b12-dev-profile.test.mjs qa/b12-dev-seams.test.mjs > /evidence/b12/tests.log 2>&1
printf 'b12=%s\n' "$?"
B15_EVIDENCE=/evidence/b15 node --experimental-strip-types --test --test-concurrency=1 qa/b15-test-core.test.mjs qa/b15-test-seams.test.mjs qa/b15-dev-profiles.test.mjs qa/b15-dev-seams.test.mjs src/lib/plan-comparison.test.mjs > /evidence/b15/tests.log 2>&1
printf 'b15=%s\n' "$?"
R7_EVIDENCE=/evidence/r7 node --experimental-strip-types --test --test-concurrency=1 qa/r7-test-core.mjs qa/r7-dev-application.test.mjs src/lib/data-query.test.mjs qa/scoped-report.test.mjs qa/confirmation.test.mjs qa/delivery.test.mjs qa/result-assessment.test.mjs > /evidence/r7/tests.log 2>&1
printf 'r7=%s\n' "$?"
