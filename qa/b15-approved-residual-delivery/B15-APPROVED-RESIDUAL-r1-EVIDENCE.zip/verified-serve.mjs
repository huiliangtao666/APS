import fs from 'node:fs';import http from 'node:http';
import {fixture} from './qa/fr027-fixture.mjs';
import {residualProfile} from './qa/b15-residual-fixture.mjs';
import {cleaningFixture} from './qa/b15-residual-cleaning-fixture.mjs';
import {scenarioFiles} from './qa/b3-material-fixture.mjs';
import {defs} from './server/planner.ts';
const f=await fixture(null,{browser:false}),profiles={source13:residualProfile('13'),source18:residualProfile('18','/fixtures/b15-originals'),cleaning:{files:scenarioFiles(cleaningFixture()),repairs:[]}};
fs.writeFileSync('/evidence/browser-profiles.json',JSON.stringify(profiles));fs.writeFileSync('/evidence/browser-defs.json',JSON.stringify(defs));fs.writeFileSync('/evidence/browser-state-path.txt',f.dir);
http.createServer((req,res)=>{if(!req.url.startsWith('/api')){const rel=decodeURIComponent(new URL(req.url,'http://test').pathname);const file='/tmp/residual-ui'+(rel==='/'?'/index.html':rel);try{const b=fs.readFileSync(file);res.setHeader('Content-Type',file.endsWith('.js')?'application/javascript':file.endsWith('.css')?'text/css':'text/html');res.end(b)}catch{res.setHeader('Content-Type','text/html');res.end(fs.readFileSync('/tmp/residual-ui/index.html'))}return;}const r=http.request(f.url+req.url,{method:req.method,headers:req.headers},up=>{res.writeHead(up.statusCode,up.headers);up.pipe(res)});r.on('error',e=>{res.writeHead(500);res.end(e.message)});req.pipe(r)}).listen(4317,'0.0.0.0',()=>console.log('RESIDUAL_BROWSER_READY '+f.url));
