from pathlib import Path
from fractions import Fraction as F
import json,csv,io,hashlib
root=Path('temp/b15-residual/verified-evidence/residual');checks=[]
def ok(label,v):
 assert v,label
 checks.append(label)
for id in ['12','13','14','15','17','18']:
 x=json.load(open(root/('adopted-'+id+'.json')));r=x['result'];d=r['input']['executionData'];p=r['plan'];orders={o['订单编号']:o for o in d['orders']};products={o['产品编号']:o for o in d['products']}
 for key in ['originalTools','originalPersonnel','originalDependencies','orders','originalBom']:
  src=p['inputCsvSources'][key];ok(id+':'+key+':sha',hashlib.sha256(src['originalText'].encode()).hexdigest()==src['sha256']);parsed=list(csv.DictReader(io.StringIO(src['originalText'].lstrip('\ufeff'))));ok(id+':'+key+':rows',len(parsed)==len(src['records']))
 for m in d['resourceMappings']:
  source=json.loads(m['源记录JSON']);target=json.loads(m['运行记录JSON']);tool=m['来源类别']=='originalTools';ok(id+':map:'+m['来源编号']+':capacity',F(source['可用数量' if tool else '可用人数'])==F(target['可用数量' if tool else '人员数量']));ok(id+':map:'+m['来源编号']+':start',F(source['最早可用分钟' if tool else '起始分钟'])==F(target['可用起始分钟']));ok(id+':map:'+m['来源编号']+':end',F(source['最晚可用分钟' if tool else '结束分钟'])==F(target['可用结束分钟']))
 for n,dm in enumerate(p['materialDemands']):
  o=orders[dm['orderId']];product=products[o['产品编号']];q=F(o['合格需求'])-F(o.get('已完成合格数量') or '0');pb=next((b for b in p.get('productionBatches',[]) if b['id']==dm.get('productionBatchId')),None)
  if pb:q=F(int(pb['qualifiedKg']['numerator']),int(pb['qualifiedKg']['denominator']))
  b=next(b for b in d['bom'] if b['产品编号']==o['产品编号'] and b['物料编号']==dm['materialId'] and b['投料工序编号']==dm['operation'] and b['版本编号']==dm['version'])
  if b['用量类型']=='BOM物料':expected=q/F(product['总收率'])*F(b['配置用量'])/1000
  else:
   value=q/F(product['单支净重kg'])/F(product['每袋支数'])*F(b['配置用量'])/(1-F(b['损坏比例']));expected=F((value.numerator+value.denominator-1)//value.denominator)
  actual=F(int(dm['exactQuantity']['numerator']),int(dm['exactQuantity']['denominator']));ok(id+':material:'+str(n),actual==expected)
 for t in p['tasks']:
  source=next(a for a in d['times'] if a['产品编号']==t['productId'] and a['工序编号']==t['operation']);ok(id+':duration:'+t['id'],t['end']-t['start']==int(source['固定分钟']));pre=next((a for a in p['tasks'] if a['id']==t['predecessor']),None);ok(id+':precedence:'+t['id'],not pre or pre['end']<=t['start'])
 for g in p.get('resourceBatches',[]):
  members=[b for b in p['productionBatches'] if b['id'] in g['members']];field='qualifiedKg' if g['basis']=='合格产出' else 'inputKg';load=sum((F(int(b[field]['numerator']),int(b[field]['denominator'])) for b in members),F(0));ok(id+':load:'+g['id'],load==F(int(g['exactLoadKg']['numerator']),int(g['exactLoadKg']['denominator'])))
for reverse,duration,wait in [('false',10,5),('true',20,7)]:
 x=json.load(open(root/('cleaning-'+reverse+'.json')));p=x['result']['plan'];a=next(t for t in p['tasks'] if t['orderId']=='A');b=next(t for t in p['tasks'] if t['orderId']=='B');inspection=p['changeoverAssessment']['domain']['inspections'][0];ok('cleaning:'+reverse+':actual-end',a['end']==30 and b['start']==90);ok('cleaning:'+reverse+':duration',inspection['end']==a['end']+duration);ok('cleaning:'+reverse+':wait',inspection['readyAt']==a['end']+duration+wait);ok('cleaning:'+reverse+':occupations',len(p['changeoverAssessment']['acceptedOccupations'])==3)
shared=json.load(open(root/'cleaning-shared-pool.json'));ok('shared:one',shared[0]['plan']['changeoverAssessment']['status']=='problem' and shared[0]['plan']['changeoverAssessment']['acceptedOccupations']==[]);ok('shared:two',shared[1]['plan']['changeoverAssessment']['status']=='pass')
Path('temp/b15-residual/independent-oracle.json').write_text(json.dumps({'checks':len(checks),'pass':len(checks),'fail':0,'method':'Python stdlib CSV/SHA256/Fraction/source duration and predecessor reconstruction; explicit asymmetric timing and shared pool expectations','assertions':checks},ensure_ascii=False,indent=2));print('independent',len(checks),'PASS')
