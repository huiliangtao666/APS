import fs from 'node:fs';import path from 'node:path';import{createHash}from'node:crypto';
import {fixture}from'./qa/fr027-fixture.mjs';import{residualProfile}from'./qa/b15-residual-fixture.mjs';
const rows=[];
for(const id of ['12','13','14','15','17','18']){const f=await fixture(),profile=residualProfile(id,id<'15'?'/fixtures/originals':'/fixtures/b15-originals');try{
 for(const kind of ['untouched19','configured-with-all-original-stage-sources']){
  let files,repairs=[];if(kind==='untouched19')files=profile.originals;else{const selected=profile.originals.filter(f=>['13','14','18','19'].includes(f.name.slice(0,2)));files=profile.files.filter(f=>!selected.some(o=>o.name===f.name));files.push(...selected);repairs=profile.repairs;}
  const before=fs.existsSync(path.join(f.dir,'business.json'))?f.bytes():null,result=await f.call('/imports/preview',{revision:0,inputStage:'supported',files,repairs});const after=fs.existsSync(path.join(f.dir,'business.json'))?f.bytes():null;if(before!==after)throw Error('preview wrote state');
  let run=null;if(result.body.valid){await f.ok('/imports/commit',{previewId:result.body.id});const runBefore=f.bytes(),p=await f.call('/calculate',{revision:1,selection:{mode:'supported',startMinute:id==='15'?60:0,endMinute:600}});if(p.status>=300&&f.bytes()!==runBefore)throw Error('invalid calculation wrote state');run={zeroWrite:p.status>=300,status:p.status,tasks:p.body.tasks?.length,findings:p.body.findings?.map(f=>({code:f.code,message:f.message,relatedRecords:f.relatedRecords}))};}
  rows.push({id,kind,valid:result.body.valid,status:result.status,zeroWrite:true,issues:result.body.issues?.map(i=>({file:i.file,table:i.table,row:i.row,field:i.field,message:i.message,reason:i.reason})),run,sources:profile.originals.map(f=>({name:f.name,bytes:Buffer.byteLength(f.text),sha256:createHash('sha256').update(f.text).digest('hex')}))});
 }
}finally{await f.close()}}
fs.writeFileSync('/evidence/original19-admission.json',JSON.stringify(rows,null,2));console.log(rows.map(r=>({id:r.id,kind:r.kind,valid:r.valid,issues:r.issues?.length,run:r.run&&{tasks:r.run.tasks,codes:r.run.findings?.map(f=>f.code)}})));
