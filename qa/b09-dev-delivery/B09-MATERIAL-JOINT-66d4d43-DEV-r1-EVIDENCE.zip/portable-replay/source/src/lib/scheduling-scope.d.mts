export type SchedulingScope={mode:string;label:string;machineAvailability:string;checked:string[];unchecked:string[];note:string};
export function schedulingScope(mode?:string,materialEnabled?:boolean,batchEnabled?:boolean,joint?:Record<string,boolean>,delivery?:boolean):SchedulingScope;
