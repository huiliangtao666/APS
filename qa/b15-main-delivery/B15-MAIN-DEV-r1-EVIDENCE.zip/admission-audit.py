from pathlib import Path
import json,csv,io,urllib.request,urllib.error,hashlib,subprocess
port=subprocess.check_output(['docker','port','aps-main-b15-c18','4317'],text=True).strip().split(':')[-1]
out=Path('temp/main-b15/delivery-evidence/admission');out.mkdir(exist_ok=True)
def call(path,body=None):
 req=urllib.request.Request('http://127.0.0.1:'+port+'/api'+path,data=json.dumps({'reason':'B15 original19 admission Dev selftest',**body}).encode() if body else None,headers={'content-type':'application/json'})
 try:
  with urllib.request.urlopen(req) as r:return json.load(r)
 except urllib.error.HTTPError as e:return {**json.load(e),'valid':False,'httpStatus':e.code}
state=call('/state');before=Path('temp/main-b15/current18-state/business.json').read_bytes();mapping=[]
for scene in ['15','17','18']:
 folder=Path('temp/main-b15/originals/UAT-'+scene)
 files=[{'name':p.name,'text':p.read_bytes().decode('utf-8')} for p in sorted(folder.glob('*.csv')) if p.name[:2] in [str(i).zfill(2) for i in range(1,20)]]
 assert len(files)==19
 response=call('/imports/preview',{'revision':state['revision'],'inputStage':'supported','files':files})
 assert not response['valid'];assert Path('temp/main-b15/current18-state/business.json').read_bytes()==before
 (out/('UAT'+scene+'-original19.json')).write_text(json.dumps({'originalFiles':19,'zeroWrite':True,'response':response},indent=2,ensure_ascii=False))
 for f in files:
  relevant=[x for x in response.get('issues',[]) if x.get('file')==f['name'] or x.get('filename')==f['name']]
  mapping.append({'scene':'UAT-'+scene,'original_file':f['name'],'bytes':len(f['text'].encode()),'sha256':hashlib.sha256(f['text'].encode()).hexdigest(),'result':'BATCH_REJECTED_NO_SILENT_MAPPING','file_issues':json.dumps(relevant,ensure_ascii=False),'scope':'raw original bytes preserved; normalized simulation profile separate; no original19 end-to-end PASS'})
 print(scene,'original19 rejected; issues',len(response.get('issues',[])))
with open('B15-MAIN-DEV-r1-INPUT-MAPPING.csv','w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(mapping[0]));w.writeheader();w.writerows(mapping)
