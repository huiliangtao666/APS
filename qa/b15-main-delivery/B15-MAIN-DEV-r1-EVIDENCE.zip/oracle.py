import json,csv,io,hashlib
from pathlib import Path
from fractions import Fraction as F
p=Path('temp/main-b15/delivery-evidence');checks=[]
def check(id,value,details=None):
 assert value,id
 checks.append({'id':id,'result':'PASS','details':details})
for id in ['15','17','18']:
 x=json.loads((p/f'browser{id}'/f'UAT{id}-app.json').read_text());a=x['first'];b=x['next'];data=b['input']['originalInput'];plan=b['plan'];tasks=plan['tasks']
 for i,t in enumerate(tasks):
  check(f'{id}:duration:{t["id"]}',F(str(t['end']))-F(str(t['start']))==F(str(t['duration'])))
  for u in tasks[i+1:]:
   if t['machine']==u['machine'] and t.get('resourceBatchId')!=u.get('resourceBatchId') or t['machine']==u['machine'] and not t.get('resourceBatchId'):
    check(f'{id}:machine:{t["id"]}/{u["id"]}',max(t['start'],u['start'])>=min(t['end'],u['end']))
  if t.get('predecessor'):
   prev=next(q for q in tasks if q['id']==t['predecessor']);check(f'{id}:precedence:{t["id"]}',prev['end']<=t['start'])
 check(id+':no-promise',all(not o.get('promised',False) for o in plan['deliveryAssessment']['orders']))
 original_csv=(p/f'browser{id}'/f'UAT{id}-original.csv').read_bytes().decode('utf-8-sig');candidate_csv=(p/f'browser{id}'/f'UAT{id}-candidate.csv').read_bytes().decode('utf-8-sig')
 parsed=list(csv.reader(io.StringIO(candidate_csv)))
 check(id+':native-csv',all(any(row and row[0]==t['id'] and F(row[5])==F(str(t['start'])) and F(row[6])==F(str(t['end'])) for row in parsed) for t in tasks) and a['run']['id'] in original_csv)
 if id=='15':
  check('15:completed',[(t['start'],t['end']) for t in tasks if t['orderId']=='A']==[(0,30),(30,60)])
  check('15:B-material180',next(t for t in tasks if t['id']=='B-MIX')['start']>=180)
  check('15:historical-ledger',plan['originalResourceProtection']==a['plan']['originalResourceProtection'])
  check('15:consumption',plan['execution']['consumption']==a['plan']['execution']['consumption'])
  check('15:no-improvement',x['comparison']['orderOutcome']=='unchanged-no-delivery-improvement')
 elif id=='17':
  o=plan['deliveryAssessment']['orders'][0];check('17:heat120',next(t for t in tasks if t['operation']=='HEAT')['duration']==120)
  check('17:chain290',sum(F(str(t['duration'])) for t in tasks)==290)
  check('17:350/260',o['completionMinute']==290 and o['expectedDeliverableMinute']==290+60 and o['delayMinutes']==290+60-90)
 else:
  o=data['orders'][0];product=next(r for r in data['products'] if r['产品编号']==o['产品编号']);bom=next(r for r in data['bom'] if r['物料编号']=='LEAN')
  expected=F(o['合格需求'])/F(product['总收率'])*F(bom['配置用量'])/1000
  check('18:independent175',expected==175 and F(str(next(r for r in plan['materialDemands'] if r['materialId']=='LEAN')['quantity']))==expected)
  mix=next(t for t in tasks if t['operation']=='MIX');fill=next(t for t in tasks if t['operation']=='FILL')
  check('18:continuous40',mix['end']-mix['start']==40 and any(F(c['起始分钟'])<=mix['start'] and F(c['结束分钟'])>=mix['end'] for c in data['calendars'] if c['是否工作']=='是'))
  check('18:G60at130',fill['start']>=130 and data['tools'][0]['工装编码']=='G60')
check('restore-original-native-bytes',(p/'browser18/UAT18-original.csv').read_bytes()==(p/'browser18/UAT18-original-after-edits.csv').read_bytes())
out={'method':'independent Fraction arithmetic and interval/event/source checks; no planner PASS used as oracle','checks':checks,'total':len(checks),'pass':len(checks)}
Path('temp/main-b15/delivery-evidence/oracle.json').write_text(json.dumps(out,indent=2));print(json.dumps({'total':len(checks),'pass':len(checks)}))
