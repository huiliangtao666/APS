from pathlib import Path
from fractions import Fraction
import math,csv,json,hashlib,urllib.request,subprocess,time,statistics
p=Path('temp/main-r7');b=p/'final-browser-evidence';check=[]
def ok(id,condition,detail):
 assert condition,id;check.append({'id':id,'result':'PASS','detail':detail})
c=json.loads((b/'confirmation.json').read_text());plan=c['snapshot']['plan'];inputs=c['snapshot']['originalInput'];tasks=plan['tasks'];demands=plan['materialDemands'];f=lambda q:Fraction(int(q['numerator']),int(q['denominator']))
for kind in ['orders','tasks','occupation','materials','unplanned','differences','tasks-empty']:
 r=json.loads((b/(kind+'-view.json')).read_text());rows=list(csv.reader((b/(kind+'.csv')).read_text(encoding='utf-8-sig').splitlines()));ok('CSV_'+kind,rows[6:]==r['rows'] and rows[1][1]==r['viewId'],'Python csv parsing equals exact page/API records and view ID');meta=json.loads(rows[2][1]);ok('PROVENANCE_'+kind,meta['inputVersionId']==plan['inputVersionId'] and meta['lines']==['L01'] and '模拟' in meta['simulation'],'Frozen input ID/line/simulation retained')
for d in demands:
 if d['materialId']=='BAG':expected=Fraction(math.ceil(Fraction(240)/Fraction('.04')/10/Fraction('.99')))
 else:expected=Fraction(240)/Fraction('.96')*Fraction({'LEAN':650,'FAT':150,'WATER':150,'PREMIX':50}[d['materialId']])/1000
 ok('MATERIAL_'+d['materialId'],f(d['exactQuantity'])==expected,{'expectedFraction':str(expected),'actualFraction':str(f(d['exactQuantity']))})
 ok('ALLOCATION_'+d['materialId'],sum((f(a['exactQuantity']) for a in d['allocations']),Fraction())==expected,'Exact allocated quantity conserves demand')
lean=next(d for d in demands if d['materialId']=='LEAN');ok('LEAN_AVAILABLE',f(lean['allocations'][0]['exactQuantity'])==Fraction('137.5')-Fraction('37.5') and f(lean['allocations'][1]['exactQuantity'])==Fraction('62.5'),'137.5 - 37.5 = 100; 100+62.5=162.5 kg; frozen/pending/rejected/expired excluded')
for t in tasks:
 ok('DURATION_'+t['id'],t['end']-t['start']==t['duration'],'Saved integer interval conserves duration')
 if t['predecessor']:ok('PRECEDENCE_'+t['id'],next(x for x in tasks if x['id']==t['predecessor'])['end']<=t['start'],'Predecessor finishes before successor starts')
ok('DATA_GATE_NOT_AUTHORITY',c['snapshot']['handoff']['finalIndependentReviewRequired'] is True and c['snapshot']['handoff']['workflowActionPerformed'] is False,'Fresh actual resource/material review and role transaction separate from data gate')
statefile=p/'delivery-selftest-state/business.json';state=statefile.read_bytes();before=hashlib.sha256(state).hexdigest();base='http://127.0.0.1:18223'
def get(path):
 with urllib.request.urlopen(base+path) as r:return r.read()
query='/api/reports?query='+urllib.parse.quote(json.dumps(json.loads((b/'tasks-view.json').read_text())['query'],separators=(',',':')));response=get(query);samples=[]
for i in range(100):
 st=time.perf_counter();assert get(query)==response;samples.append((time.perf_counter()-st)*1000)
perf={'productSha':json.loads(get('/api/uat-build'))['productSha'],'profile':'Explicit B3-v1 one line / one order / 6 devices / 100 sequential HTTP task queries; no AC27 agreed threshold','requestCount':100,'responseBytes':len(response),'minMs':min(samples),'medianMs':statistics.median(samples),'p95Ms':sorted(samples)[94],'maxMs':max(samples),'AC27Verdict':'NOT_SIGNED','stateUnchanged':statefile.read_bytes()==state};(p/'http-query-measurement.json').write_text(json.dumps(perf,indent=2))
subprocess.run(['docker','restart','aps-main-r7-selftest-7fd9683'],check=True,capture_output=True)
for i in range(50):
 try:afterResponse=get(query);break
 except Exception:time.sleep(.1)
else:raise AssertionError('selftest restart did not respond')
ok('ACTUAL_PROCESS_RESTART',statefile.read_bytes()==state and afterResponse==response,'Business JSON bytes, report response, view ID and confirmation preserved across actual process restart')
after=hashlib.sha256(statefile.read_bytes()).hexdigest();(p/'restart-verification.json').write_text(json.dumps({'productSha':perf['productSha'],'beforeBusinessSha256':before,'afterBusinessSha256':after,'sameReportBytes':response==afterResponse,'sameConfirmation':json.loads(get('/api/confirmations/'+c['id']))==c},indent=2))
(p/'independent-checks.json').write_text(json.dumps({'checks':check,'count':len(check),'oracle':'Python csv + Fraction + direct interval checks; no product scheduling formula called'},ensure_ascii=False,indent=2));print('independent checks',len(check),'PASS; restart stable')
