from fractions import Fraction as F
import pathlib,json,csv,hashlib
E=pathlib.Path(__file__).parent
results=json.loads((E/'contract-results.json').read_text());checks=[]
def ck(id,claim,actual,expected=True):
 ok=actual==expected;checks.append({'case':id,'assertion':claim,'expected':expected,'actual':actual,'result':'PASS'if ok else'FAIL'});assert ok,(id,claim,actual,expected)
for r in results:
 id=r['id']
 if id=='old-six':
  rows=r['before']['plan']['tasks']; expected=[(o+'-'+op,op,s,e)for o in ['A','B','C']for op,s,e in [('MIX',0,30),('FILL',30,60)]]
  ck(id,'six explicit identities / original raw timeline',[(x['id'],x['operation'],x['start'],x['end'])for x in rows],expected)
  ck(id,'no route maximum exists',all(not str(x.get('最大等待分钟','')).strip()for x in r['rawBeforeMax']['routes']))
  ck(id,'global admission error with message, zero tasks',not r['rejected']['plan']['tasks'] and any(x['code']=='RULE / CONFIG'and '显式加工/冷却' in x['message']for x in r['rejected']['plan']['findings']))
  ck(id,'rejected MAX not pass',next(x for x in r['rejected']['verification']['ruleStatuses']if x['id']=='MAX_LAG')['status'],'not_checked')
 elif id in ['legal-five-all-resources','explicit-zero-max']:
  d,p=r['data'],r['plan'];names=['MIX','FILL','HEAT','COOL','PACK'];ck(id,'original complete 5-operation coverage',[t['operation']for t in p['tasks']],names)
  for i,t in enumerate(p['tasks']):
   raw=next(x for x in d['times']if x['工序编号']==t['operation']);ck(id,t['operation']+' fixed time from raw input',t['end']-t['start'],int(raw['固定分钟']))
   ck(id,t['operation']+' demand identity',F(str(t['quantity'])),F(d['orders'][0]['合格需求']))
   if i:ck(id,t['operation']+' raw predecessor order',t['start']>=p['tasks'][i-1]['end'])
  h,c=p['tasks'][2:4];maximum=int(next(x['最大等待分钟']for x in d['routes']if x['工序编号']=='COOL'))
  ck(id,'wait inequality from raw endpoints',0<=c['start']-h['end']<=maximum)
  ck(id,'cold shutdown [180,210) avoided',c['end']<=180 or c['start']>=210)
  ck(id,'upstream shifted: earliest180 end cannot satisfy210 cold-open/max10',h['end']>=210-maximum)
  demand=F(d['orders'][0]['合格需求']);yieldrate=F(d['products'][0]['总收率']);ck(id,'input250 from240/.96',F(str(h['loadKg'])),demand/yieldrate);ck(id,'output240',F(str(c['loadKg'])),demand)
  ck(id,'raw material ledger exactly250kg',sum((F(str(x['quantity']))for x in p['materialDemands']if x['unit']=='kg'and x['committed']),F(0)),demand/yieldrate)
  limits={'MAXLAG-T':F(d['tools'][0]['可用数量']),'MAXLAG-G':F(d['personnelGroups'][0]['人员数量']),'COLD':F(next(x['容量']for x in d['batchResources']if x['资源编号']=='COLD'))}
  for rid,cap in limits.items():
   rows=[x for x in p['resourceReservations']if x['resourceId']==rid];ck(id,rid+' resource is actually reserved',bool(rows));ck(id,rid+' exact sweep capacity',all(sum((F(str(x['quantity']))for x in rows if x['start']<=t<x['end']),F(0))<=cap for t in sorted({x['start']for x in rows})))
  ck(id,'rule adoption preserves all enabled hard constraints',set(['MACHINE','PRECEDENCE','CALENDAR','LABOR','MATERIAL','MOLD','CAPACITY','PROGRAM','MAX_LAG','STORAGE']).issubset(p['rules']))
 elif id.startswith('wait-'):
  w=int(id.split('-')[1]);h=next(x for x in r['plan']['tasks']if x['operation']=='HEAT');c=next(x for x in r['plan']['tasks']if x['operation']=='COOL');rawlimit=int(next(x['最大等待分钟']for x in r['input']['executionData']['routes']if x['工序编号']=='COOL'));wait=F(str(c['start']))-F(str(h['end']));ck(id,'fixed independent heat interval',[h['start'],h['end']],[90-w,210-w]);ck(id,'raw endpoint subtraction',wait,F(w));ck(id,'raw max10 legal iff0<=wait<=10',0<=wait<=rawlimit,w<=10)
  expected='pass'if 0<=wait<=rawlimit else'problem';ck(id,'independent checker agrees with raw arithmetic',next(x for x in r['verification']['ruleStatuses']if x['id']=='MAX_LAG')['status'],expected)
  if w>10:ck(id,'exact raw shortfall',max(F(0),wait-rawlimit),F(w-10))
  for row in r['plan']['resourceReservations']:
   if h['id']in row['taskIds']:ck(id,row['type']+' heat ledger moved consistently',[row['start'],row['end']],[90-w,210-w])
 elif id.startswith('state-'):
  status=next((x['status']for x in r['verification']['ruleStatuses']if x['id']=='MAX_LAG'),None);ck(id,'disabled/future/missing/minimal is never max PASS',status in [None,'not_checked'])
 else:
  ck(id,'negative has no scheduled task',r['plan']['tasks'],[]);ck(id,'negative has no resource reservation',r['plan']['resourceReservations'],[]);ck(id,'negative surfaces explicit message',bool(r['plan']['findings']) and all(bool(x['message'])for x in r['plan']['findings']))
  if 'verification'in r:ck(id,'negative cannot be max PASS',next((x['status']for x in r['verification']['ruleStatuses']if x['id']=='MAX_LAG'),None)!='pass')
for c in checks:
 for k in ['actual','expected']:c[k]=str(c[k])
with (E/'oracle.csv').open('w')as f:
 w=csv.DictWriter(f,fieldnames=['case','assertion','expected','actual','result']);w.writeheader();w.writerows(checks)
print(json.dumps({'independent_fraction_and_interval_assertions':len(checks),'pass':sum(x['result']=='PASS'for x in checks),'cases':len(results)}))
