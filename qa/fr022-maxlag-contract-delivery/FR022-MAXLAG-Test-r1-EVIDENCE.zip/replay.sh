#!/bin/sh
set -eu
# Run INSIDE the application container; no install, preview, or deployment.
# Extract evidence ZIP to a fresh directory before executing.
mkdir -p source
 tar -xf fixed-source.tar -C source
cd source
FR022_OUT=../replayed node --experimental-strip-types --test qa/fr022-maxlag-contract.test.mjs qa/joint-resources.test.mjs src/lib/business-rules.test.mjs src/lib/expected-supply.test.mjs src/lib/independent-verification.test.mjs src/lib/inventory.test.mjs src/lib/material-allocation.test.mjs
cd ..
cp oracle.py replayed/oracle.py
# Independent Python stdlib oracle: run python3 replayed/oracle.py on the host.
# The Node application container does not include Python; no install is needed.
