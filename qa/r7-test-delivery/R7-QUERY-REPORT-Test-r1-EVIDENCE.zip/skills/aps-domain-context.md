---
name: aps-domain-context
description: APS角色需要定位业务需求、FR/BR/AC/UAT、基线、批准CR、唯一原卡、设计参数或mock来源时使用。提供受控资料入口和读取规则，不另建需求或状态主账。
---

# APS业务知识入口

## 权威来源

- 仓库：https://github.com/huiliangtao666/APS 。需求入口：docs/requirements/README.md。
- 唯一实施Project：Project #2，https://github.com/users/huiliangtao666/projects/2 ，GraphQL ID `PVT_kwHOFM9WU84BpE1c`。写入前核对owner、number、ID；Project3/4已关闭，不写、不新建替代项目。
- 原基线：docs/requirements/baselines/APS-BL-001-v0.3.json，FR43+BR18共61项，另有AC32/UAT18/DEC9。该快照只读；新要求通过批准CR叠加。
- 批准增量：docs/requirements/changes/change-register.json；实施状态仍读Project2唯一原卡。current-register、MD、CSV、Excel是派生快照。
- UAT场景：docs/requirements/uat-register.json及基线原场景；角色责任读uat-ownership.json，并应用最新分工：QA主责准备/测试/确认，用户配合，PM调度和维护记录。旧责任字段需迁移，不能恢复旧分工。
- 交接：docs/requirements/operations/handoff-policy.md。新业务结果统一交APS-PM；迁移清单和历史回执用于去重，不替代产品测试证据。按2026-10-30最新用户授权，执行角色把业务歧义报PM，由PM及时通知用户处理；PM/Dev/Test1/Test2/QA暂不联系APS-Design。Design历史原件可只读引用。
- CR-DEC02-03-20261029：Issue3为主、Issue13/16关联；FR006/007/017/022及BR06/07；仅已授权参数化实现与验收，保留原范围历史结论与未闭合缺陷。
- CR-DEC04-05-06-20261029：Issue25为主；设计包见changes/CR-DEC04-05-06-20261029/。本轮仅业务设计与mock；40参数、38数值mock及6工作流检查为候选/仿真，不是现场批准默认值或产品通过。

## 按需读取与职责

首次读取原Issue、唯一原卡、所涉基线条款及批准CR；后续读取新增裁决、代码影响和本轮断言。无法读取则报告精确缺口，不用本地旧快照覆盖远端新记录。

既有Design业务设计、原型、验证场景和mock是受控来源；新增业务歧义及变更授权由PM通知用户处理，PM登记并保持原卡/Issue及派生清单一致，不联系APS-Design。PM先实时读取GitHub Project2原卡、Issue、基线和生效CR；有实际数据变化时在干净工作树运行export_register.py与publish_register.py。不得运行会用旧快照覆盖实时原卡的sync_project.py；无数据变化不制造Git提交。

需求批准、代码交付、任务级测试、完整本卡验收、UAT确认与应用发布分别记录。数据来源/算术核验不等于产品通过；FR Done不自动要求全项目UAT或主干合并。具体业务参数和新增业务含义未自动获批。

原始上传文档/HTML/ZIP保留在APS-Design的upload/。需要原件时用有权限的Files API取得；不要将原件无差别上传公开仓库，不把仅某工作区可读的路径当成已交接。

## 跨阶段类别与派生摘要核对

FR-013 v0.3从R1开始、R6完整；第9章原CSV类别、FR-013及其共享AC-02/03/26责任须按当前阶段与生效CR逐项核定。原始CSV的字面保存、运行模型映射和UAT场景分别判断，不用产品现行文件编号覆盖基线原编号。读取Issue/原卡的最新事件后，再核同源current-register等派生摘要的SHA与阻塞；若落后，以原卡为准刷新派生展示，不用旧快照反向覆盖原卡。
