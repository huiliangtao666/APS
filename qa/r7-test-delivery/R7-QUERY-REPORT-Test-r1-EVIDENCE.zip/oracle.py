import json,pathlib,hashlib,sys
from fractions import Fraction as F
p=pathlib.Path(sys.argv[1]);views=json.load(open(p/'six-views.json'));checks=[]
def check(i,actual,expected):
 assert actual==expected,(i,actual,expected)
 checks.append({'id':i,'actual':str(actual),'expected':str(expected),'result':'PASS'})
def exact(r):return F(int(r['numerator']),int(r['denominator']))
orders=[json.loads(r[1])for r in views['orders']['rows']];check('source-demand-literal',orders[0]['inputRecord']['合格需求'],'480');check('source-unit',orders[0]['inputRecord']['数量单位'],'kg');check('source-line',orders[0]['inputRecord']['产线编号'],'L01')
tasks=[json.loads(r[1])['record']for r in views['tasks']['rows']];check('route-count-not-completion-sum',len(tasks),2)
for i,(start,end)in enumerate([(0,30),(30,60)]):
 check('task-start-'+str(i),F(tasks[i]['开始分钟']),F(start));check('task-end-'+str(i),F(tasks[i]['结束分钟']),F(end));check('task-duration-'+str(i),F(tasks[i]['工时分钟']),F(end-start));check('task-unit-'+str(i),tasks[i]['数量单位'],'kg');check('task-line-'+str(i),tasks[i]['产线编号'],'L01')
check('half-open-boundary',F(tasks[0]['结束分钟'])<=F(tasks[1]['开始分钟']),True)
material={json.loads(r[1])['record']['materialId']:json.loads(r[1])['record']for r in views['materials']['rows']}
# Existing approved explicit mock quantities; no new product formula or default.
inputKg=F(480)/F('0.96');check('mock-input-kg',inputKg,F(500))
for m,ratio in [('LEAN',650),('FAT',150),('WATER',150),('PREMIX',50)]:
 expected=inputKg*F(ratio,1000);r=material[m];check('exact-demand-'+m,exact(r['exactQuantity']),expected);check('exact-allocation-'+m,sum((exact(x['exactQuantity'])for x in r['allocations']),F(0)),expected);check('source-stock-remaining-'+m,exact(r['allocations'][0]['exactRemaining']),F(10000)-expected)
bags=F(480)/F('.04')/10/(1-F('.01'));ceil=(bags.numerator+bags.denominator-1)//bags.denominator;check('exact-bag-loss-ceiling',exact(material['BAG']['exactQuantity']),F(ceil))
assessment=orders[0]['assessment'];check('completed-once-not-route-sum',assessment['knownCompletedQuantity'],480);check('unchecked-delivery-null',assessment['expectedDeliverableMinute'],None);check('unknown-delivery-quantity',assessment['unknownDeliverableQuantity'],480);check('not-a-promise',assessment['promised'],False)
for row in views['occupation']['rows']:check('unallocated-not-idle-'+json.loads(row[1])['record']['id'],json.loads(row[1])['record']['availableNow'],None)
empty=json.load(open(p/'empty-query.json'));check('empty-query-rows',len(empty['rows']),0);check('empty-keeps-provenance',empty['provenance']['inputVersionId'],views['tasks']['provenance']['inputVersionId'])
partial=json.load(open(p/'partial-gate.json'));check('partial-list',len(partial['unplanned']),1);check('partial-full-quantity-not-reduced',partial['unplanned'][0]['quantity'],480);check('partial-final-independent-required',partial['finalIndependentReviewRequired'],True)
contract=json.load(open(p/'exchange-contract.json'));check('original-chapter-categories',len(contract['current']['chapter9']),19);check('actual-current-contract-count',len(contract['current']['inbound']),38);check('static-gap-records',sorted(x['table']for x in contract['historical']['gaps']),['dependencies','originalDependencies','originalResourceEvents'])
status=json.load(open(p/'package-records.json'));check('Done-without-QA',status['absent']['qaVerdict'],'NOT_EXECUTED')
result={'method':'Python stdlib Fraction / literal source / interval checks; no product PASS flags used as oracle','input_files':[{'path':f.name,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for f in p.glob('*.json')],'checks':checks,'passed':len(checks)}
pathlib.Path('temp/r7-query/oracle.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print('Independent checks:',len(checks),'PASS')
