import json,pathlib,hashlib,zipfile
from fractions import Fraction as F
p=pathlib.Path(__file__).parent
raw=p/'runtime';checks=[]
def check(name,actual,expected):
 assert actual==expected,(name,actual,expected)
 checks.append({'assertion':name,'actual':str(actual),'expected':str(expected),'result':'PASS'})
u=json.loads((raw/'UAT15.json').read_text())
for side in ['before','after']:
 r=u[side];ts=r['plan']['tasks'];a=[(t['operation'],t['start'],t['end'])for t in ts if t['orderId']=='A']
 check(side+' completed A',a,[('MIX',0,30),('FILL',30,60)])
 b=next(t for t in ts if t['orderId']=='B'and t['operation']=='MIX')
 check(side+' B material boundary',b['start']>=180,True)
 check(side+' raw fact snapshot',r['plan']['execution']['facts'],r['data']['executionFacts'])
 check(side+' raw consumption snapshot',r['plan']['execution']['consumption'],r['data']['executionMaterials'])
 check(side+' original history preserved',r['data']['originalResourceEvents'],u['before']['data']['originalResourceEvents'])
check('new personnel count',u['after']['data']['personnelGroups'][0]['人员数量'],'2')
x=json.loads((raw/'UAT17.json').read_text());r=x['complete'];d=r['data'];ts=r['plan']['tasks'];o=r['plan']['deliveryAssessment']['orders'][0]
durations=[30,30,120,60,50]
check('route fixed duration sum',sum(durations),290)
check('fixed heat',next(t['end']-t['start']for t in ts if t['operation']=='HEAT'),120)
check('complete route per operation',[t['duration']for t in ts],durations)
wait=int(d['products'][0]['模拟交付等待分钟']);check('explicit wait',wait,60)
check('conditional deliverable',o['expectedDeliverableMinute'],290+wait)
check('delay over requested90',o['delayMinutes'],350-90)
check('clock reference13:50',o['expectedDeliverableAt'],'2026-11-02T05:50:00.000Z')
check('partial stays unknown',x['partial']['plan']['deliveryAssessment']['orders'][0]['expectedDeliverableMinute'],None)
x=json.loads((raw/'UAT18.json').read_text());a=x['original'];b=x['modified'];d=b['data'];order=d['orders'][0];product=next(p for p in d['products']if p['产品编号']==order['产品编号']);lean=next(q for q in d['bom']if q['物料编号']=='LEAN')
need=F(order['合格需求'])/F(product['总收率'])*F(lean['配置用量'])/1000
check('normalized lean independent Fraction',need,F(175))
check('planner lean equals independent arithmetic',F(str(next(q['quantity']for q in b['plan']['materialDemands']if q['materialId']=='LEAN'))),need)
check('original lean remains650',next(q['配置用量']for q in a['data']['bom']if q['物料编号']=='LEAN'),'650')
check('original qty remains240',a['data']['orders'][0]['合格需求'],'240')
check('modified actual windows',[(t['start'],t['end'])for t in b['plan']['tasks']],[(60,100),(130,160)])
for task in b['plan']['tasks']:
 check('continuous work '+task['id'],any(F(c['起始分钟'])<=task['start']and task['end']<=F(c['结束分钟'])for c in d['calendars']),True)
check('G60 source available130',d['tools'][0]['可用起始分钟'],'130')
check('G60 selected',d['resourceClaims'][0]['资源编号'],'G60')
for n in ['15','17','18']:
 w=json.loads((raw/('worker-'+n+'.json')).read_text());check('actual built worker '+n,w['actualApplicationWorker'],True)
s=json.loads((raw/'persistence.json').read_text());check('restart bytes unchanged',s['bytesUnchanged'],True);check('different process',s['pidBefore']!=s['pidAfter'],True)
manifest=json.loads((p/'original-hashes.json').read_text());n=0
with zipfile.ZipFile(manifest['archive'])as z:
 for f in manifest['files']:
  b=z.read(f['archive_path']);assert b==pathlib.Path(f['local_path']).read_bytes();assert len(b)==f['bytes'];assert hashlib.sha256(b).hexdigest()==f['sha256'];n+=1
check('original bytes matched',n,153)
(p/'oracle.json').write_text(json.dumps({'basis':'v0.3 UAT15/17/18 bounds; independent stdlib Fraction and interval checks; no use of planner PASS flag','checks':checks},ensure_ascii=False,indent=2))
print('independent checks',len(checks),'PASS')
